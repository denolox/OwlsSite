package me.owlsTelemetry;

import me.owlsTelemetry.config.ConfigManager;
import me.owlsTelemetry.database.BatchProcessor;
import me.owlsTelemetry.database.DatabaseManager;
import me.owlsTelemetry.listeners.CriticalEventsListener;
import me.owlsTelemetry.output.OutputManager;
import me.owlsTelemetry.protection.CrashExploitDetector;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * OwlsTelemetry v2.0 - Оптимизировано для крупных серверов
 * 
 * Фокус:
 * - Максимальная производительность (batch operations, HikariCP)
 * - Защита от краша (anti-DDoS, anti-flood)
 * - MySQL интеграция
 * - Готовность к веб-интерфейсу
 * 
 * @author ClanMember
 * @version 2.0
 */
public final class OwlsTelemetry extends JavaPlugin {

    private ConfigManager configManager;
    private DatabaseManager databaseManager;
    private BatchProcessor batchProcessor;
    private CrashExploitDetector crashDetector;
    private OutputManager outputManager;
    private CriticalEventsListener eventsListener;

    @Override
    public void onEnable() {
        long startTime = System.currentTimeMillis();
        
        getLogger().info("=".repeat(50));
        getLogger().info("  OwlsTelemetry v2.0 - Enterprise Edition");
        getLogger().info("  Загрузка оптимизированной системы...");
        getLogger().info("=".repeat(50));

        try {
            // 1. Конфигурация
            getLogger().info("[1/6] Загрузка конфигурации...");
            this.configManager = new ConfigManager(this);

            // 2. База данных
            getLogger().info("[2/6] Подключение к MySQL...");
            this.databaseManager = new DatabaseManager(this, configManager);
            databaseManager.initialize();

            // 3. Batch Processor
            getLogger().info("[3/6] Инициализация BatchProcessor...");
            this.batchProcessor = new BatchProcessor(this, databaseManager, configManager);
            batchProcessor.start();

            // 4. Anti-Crash Protection
            getLogger().info("[4/6] Активация защиты от краша...");
            this.crashDetector = new CrashExploitDetector(this, configManager, batchProcessor);

            // 5. Output Manager
            getLogger().info("[5/6] Настройка Discord интеграции...");
            this.outputManager = new OutputManager(this, configManager);

            // 6. Event Listener
            getLogger().info("[6/6] Регистрация критических событий...");
            this.eventsListener = new CriticalEventsListener(this, configManager, batchProcessor, crashDetector);
            Bukkit.getPluginManager().registerEvents(eventsListener, this);

            long loadTime = System.currentTimeMillis() - startTime;
            
            getLogger().info("=".repeat(50));
            getLogger().info("  ✓ OwlsTelemetry v2.0 успешно загружен!");
            getLogger().info("  ✓ Время загрузки: " + loadTime + " мс");
            getLogger().info("  ✓ Database: " + (databaseManager.testConnection() ? "OK" : "ERROR"));
            getLogger().info("  ✓ Anti-Crash: " + (configManager.isAntiCrashEnabled() ? "ENABLED" : "DISABLED"));
            getLogger().info("  ✓ Discord: " + (configManager.isDiscordEnabled() ? "ENABLED" : "DISABLED"));
            getLogger().info("=".repeat(50));

            // Discord уведомление
            if (configManager.isDiscordEnabled()) {
                outputManager.sendDiscordAlert(
                    "✅ OwlsTelemetry v2.0 ONLINE",
                    String.format("Сервер запущен\nВремя загрузки: %d мс", loadTime)
                );
            }
            
            // Тест подключения к веб-API
            if (configManager.isWebApiEnabled()) {
                getLogger().info("🔗 Тестирование подключения к веб-API...");
                // Тест будет выполнен в CriticalEventsListener
            }

        } catch (Exception e) {
            getLogger().severe("=".repeat(50));
            getLogger().severe("  ❌ КРИТИЧЕСКАЯ ОШИБКА ЗАГРУЗКИ!");
            getLogger().severe("  " + e.getMessage());
            getLogger().severe("=".repeat(50));
            e.printStackTrace();
            Bukkit.getPluginManager().disablePlugin(this);
        }
    }

    @Override
    public void onDisable() {
        getLogger().info("=".repeat(50));
        getLogger().info("  OwlsTelemetry v2.0 - Остановка...");
        getLogger().info("=".repeat(50));

        try {
            // 1. Сохранить активные сессии
            if (eventsListener != null) {
                getLogger().info("[1/3] Сохранение активных сессий...");
                eventsListener.flushActiveSessions();
            }

            // 2. Остановить BatchProcessor и flush
            if (batchProcessor != null) {
                getLogger().info("[2/3] Flush очереди событий...");
                batchProcessor.shutdown();
                getLogger().info("  ✓ Обработано записей: " + batchProcessor.getTotalProcessed());
            }

            // 3. Закрыть соединение с БД
            if (databaseManager != null) {
                getLogger().info("[3/3] Закрытие connection pool...");
                databaseManager.shutdown();
            }

            getLogger().info("=".repeat(50));
            getLogger().info("  ✓ OwlsTelemetry остановлен успешно!");
            getLogger().info("=".repeat(50));

        } catch (Exception e) {
            getLogger().severe("Ошибка при остановке: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // === Геттеры для доступа к модулям ===

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public DatabaseManager getDatabaseManager() {
        return databaseManager;
    }

    public BatchProcessor getBatchProcessor() {
        return batchProcessor;
    }

    public CrashExploitDetector getCrashDetector() {
        return crashDetector;
    }

    public OutputManager getOutputManager() {
        return outputManager;
    }

    /**
     * Перезагрузка конфигурации
     */
    public void reload() {
        getLogger().info("Перезагрузка конфигурации...");
        configManager.reloadConfig();
        getLogger().info("Конфигурация перезагружена!");
    }

    /**
     * Получить статистику плагина
     */
    public String getStats() {
        return String.format(
            "OwlsTelemetry v2.0 Stats:\n" +
            "- Обработано событий: %d\n" +
            "- Очередь: %d\n" +
            "- Connection Pool: %s\n" +
            "- Uptime: %s",
            batchProcessor.getTotalProcessed(),
            batchProcessor.getQueueSize(),
            databaseManager.getPoolStats(),
            getUptime()
        );
    }

    private long startTime = System.currentTimeMillis();
    
    private String getUptime() {
        long uptime = System.currentTimeMillis() - startTime;
        long hours = uptime / 3600000;
        long minutes = (uptime % 3600000) / 60000;
        return String.format("%dч %dм", hours, minutes);
    }
}
