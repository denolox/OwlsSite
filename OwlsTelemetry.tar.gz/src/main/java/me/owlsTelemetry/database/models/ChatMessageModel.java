package me.owlsTelemetry.database.models;

import java.sql.Timestamp;
import java.util.UUID;

/**
 * Модель сообщения чата
 */
public class ChatMessageModel {
    private Long id;
    private final UUID playerUuid;
    private final String message;
    private final String channel;
    private final Timestamp sentAt;

    public ChatMessageModel(UUID playerUuid, String message, String channel, Timestamp sentAt) {
        this.playerUuid = playerUuid;
        this.message = message;
        this.channel = channel;
        this.sentAt = sentAt;
    }

    public ChatMessageModel(UUID playerUuid, String message, String channel) {
        this(playerUuid, message, channel, new Timestamp(System.currentTimeMillis()));
    }

    public Long getId() { return id; }
    public UUID getPlayerUuid() { return playerUuid; }
    public String getMessage() { return message; }
    public String getChannel() { return channel; }
    public Timestamp getSentAt() { return sentAt; }
    
    public void setId(Long id) { this.id = id; }
}

