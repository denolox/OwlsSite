package me.owlsTelemetry.database.models;

import java.sql.Timestamp;
import java.util.UUID;

/**
 * Модель выполненной команды
 */
public class CommandModel {
    private Long id;
    private final UUID playerUuid;
    private final String command;
    private final Timestamp executedAt;

    public CommandModel(UUID playerUuid, String command, Timestamp executedAt) {
        this.playerUuid = playerUuid;
        this.command = command;
        this.executedAt = executedAt;
    }

    public CommandModel(UUID playerUuid, String command) {
        this(playerUuid, command, new Timestamp(System.currentTimeMillis()));
    }

    public Long getId() { return id; }
    public UUID getPlayerUuid() { return playerUuid; }
    public String getCommand() { return command; }
    public Timestamp getExecutedAt() { return executedAt; }
    
    public void setId(Long id) { this.id = id; }
}

