package me.owlsTelemetry.database.models;

import java.sql.Timestamp;
import java.util.UUID;

/**
 * Модель игрока в базе данных
 */
public class PlayerModel {
    private final UUID uuid;
    private final String username;
    private final Timestamp firstJoin;
    private Timestamp lastSeen;

    public PlayerModel(UUID uuid, String username, Timestamp firstJoin, Timestamp lastSeen) {
        this.uuid = uuid;
        this.username = username;
        this.firstJoin = firstJoin;
        this.lastSeen = lastSeen;
    }

    public PlayerModel(UUID uuid, String username) {
        this(uuid, username, new Timestamp(System.currentTimeMillis()), new Timestamp(System.currentTimeMillis()));
    }

    public UUID getUuid() { return uuid; }
    public String getUsername() { return username; }
    public Timestamp getFirstJoin() { return firstJoin; }
    public Timestamp getLastSeen() { return lastSeen; }
    
    public void setLastSeen(Timestamp lastSeen) { this.lastSeen = lastSeen; }
}

