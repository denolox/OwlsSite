package me.owlsTelemetry.database.models;

import java.sql.Timestamp;
import java.util.UUID;

/**
 * Модель игровой сессии
 */
public class PlayerSessionModel {
    private Long id;
    private final UUID playerUuid;
    private final Timestamp joinTime;
    private Timestamp leaveTime;
    private final String ipAddress;

    public PlayerSessionModel(UUID playerUuid, Timestamp joinTime, String ipAddress) {
        this.playerUuid = playerUuid;
        this.joinTime = joinTime;
        this.ipAddress = ipAddress;
        this.leaveTime = null;
    }

    public Long getId() { return id; }
    public UUID getPlayerUuid() { return playerUuid; }
    public Timestamp getJoinTime() { return joinTime; }
    public Timestamp getLeaveTime() { return leaveTime; }
    public String getIpAddress() { return ipAddress; }
    
    public void setId(Long id) { this.id = id; }
    public void setLeaveTime(Timestamp leaveTime) { this.leaveTime = leaveTime; }
    
    /**
     * Длительность сессии в миллисекундах
     */
    public long getDuration() {
        if (leaveTime == null) {
            return System.currentTimeMillis() - joinTime.getTime();
        }
        return leaveTime.getTime() - joinTime.getTime();
    }
}

