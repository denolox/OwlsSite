package me.owlsTelemetry.database.models;

import java.sql.Timestamp;
import java.util.UUID;

/**
 * Модель убийства (PvP или PvE)
 */
public class KillModel {
    public enum VictimType {
        PLAYER, MOB
    }

    private Long id;
    private final UUID killerUuid;
    private final UUID victimUuid; // Null для мобов
    private final VictimType victimType;
    private final String weapon;
    private final String world;
    private final double x, y, z;
    private final Timestamp killedAt;

    public KillModel(UUID killerUuid, UUID victimUuid, VictimType victimType, String weapon,
                     String world, double x, double y, double z, Timestamp killedAt) {
        this.killerUuid = killerUuid;
        this.victimUuid = victimUuid;
        this.victimType = victimType;
        this.weapon = weapon;
        this.world = world;
        this.x = x;
        this.y = y;
        this.z = z;
        this.killedAt = killedAt;
    }

    public KillModel(UUID killerUuid, UUID victimUuid, VictimType victimType, String weapon,
                     String world, double x, double y, double z) {
        this(killerUuid, victimUuid, victimType, weapon, world, x, y, z, 
             new Timestamp(System.currentTimeMillis()));
    }

    public Long getId() { return id; }
    public UUID getKillerUuid() { return killerUuid; }
    public UUID getVictimUuid() { return victimUuid; }
    public VictimType getVictimType() { return victimType; }
    public String getWeapon() { return weapon; }
    public String getWorld() { return world; }
    public double getX() { return x; }
    public double getY() { return y; }
    public double getZ() { return z; }
    public Timestamp getKilledAt() { return killedAt; }
    
    public void setId(Long id) { this.id = id; }
}

