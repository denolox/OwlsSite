package me.owlsTelemetry.database;

import me.owlsTelemetry.OwlsTelemetry;
import me.owlsTelemetry.config.ConfigManager;
import me.owlsTelemetry.database.models.*;
import org.bukkit.Bukkit;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Высокопроизводительный процессор для массовой вставки данных
 * Использует batch-операции для минимизации нагрузки на БД
 */
public class BatchProcessor {
    private final OwlsTelemetry plugin;
    private final DatabaseManager databaseManager;
    private final ConfigManager config;

    // Очереди для разных типов данных
    private final ConcurrentLinkedQueue<PlayerModel> playerQueue = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<PlayerSessionModel> sessionQueue = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<CommandModel> commandQueue = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<ChatMessageModel> chatQueue = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<KillModel> killQueue = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<ExploitModel> exploitQueue = new ConcurrentLinkedQueue<>();

    private final AtomicInteger totalProcessed = new AtomicInteger(0);
    private int taskId = -1;

    public BatchProcessor(OwlsTelemetry plugin, DatabaseManager databaseManager, ConfigManager config) {
        this.plugin = plugin;
        this.databaseManager = databaseManager;
        this.config = config;
    }

    /**
     * Запуск автоматического flush по расписанию
     */
    public void start() {
        int interval = config.getBatchFlushInterval() * 20; // В тиках
        
        taskId = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            try {
                flushAll();
            } catch (Exception e) {
                plugin.getLogger().warning("Ошибка при flush: " + e.getMessage());
            }
        }, interval, interval).getTaskId();

        plugin.getLogger().info("BatchProcessor запущен (flush каждые " + config.getBatchFlushInterval() + " сек)");
    }

    /**
     * Остановка и финальный flush
     */
    public void shutdown() {
        if (taskId != -1) {
            Bukkit.getScheduler().cancelTask(taskId);
        }
        flushAll();
        plugin.getLogger().info("BatchProcessor остановлен. Обработано записей: " + totalProcessed.get());
    }

    // === Добавление в очереди ===

    public void addPlayer(PlayerModel player) {
        playerQueue.offer(player);
        checkAndFlush(playerQueue);
    }

    public void addSession(PlayerSessionModel session) {
        sessionQueue.offer(session);
        checkAndFlush(sessionQueue);
    }

    public void addCommand(CommandModel command) {
        commandQueue.offer(command);
        checkAndFlush(commandQueue);
    }

    public void addChat(ChatMessageModel chat) {
        chatQueue.offer(chat);
        checkAndFlush(chatQueue);
    }

    public void addKill(KillModel kill) {
        killQueue.offer(kill);
        checkAndFlush(killQueue);
    }

    public void addExploit(ExploitModel exploit) {
        exploitQueue.offer(exploit);
        checkAndFlush(exploitQueue);
    }

    /**
     * Проверка размера очереди и автоматический flush при достижении лимита
     */
    private void checkAndFlush(ConcurrentLinkedQueue<?> queue) {
        if (queue.size() >= config.getBatchSize()) {
            Bukkit.getScheduler().runTaskAsynchronously(plugin, this::flushAll);
        }
    }

    /**
     * Flush всех очередей
     */
    public void flushAll() {
        long start = System.currentTimeMillis();
        int flushed = 0;

        flushed += flushPlayers();
        flushed += flushSessions();
        flushed += flushCommands();
        flushed += flushChat();
        flushed += flushKills();
        flushed += flushExploits();

        if (flushed > 0) {
            totalProcessed.addAndGet(flushed);
            long time = System.currentTimeMillis() - start;
            
            if (config.isLogPerformance()) {
                plugin.getLogger().info(String.format(
                    "Batch flush: %d записей за %d мс (%.2f записей/сек)",
                    flushed, time, (flushed * 1000.0) / time
                ));
            }
        }
    }

    private int flushPlayers() {
        if (playerQueue.isEmpty()) return 0;

        List<PlayerModel> batch = new ArrayList<>();
        PlayerModel player;
        while ((player = playerQueue.poll()) != null && batch.size() < config.getBatchSize()) {
            batch.add(player);
        }

        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "INSERT INTO players (uuid, username, first_join, last_seen) " +
                 "VALUES (?, ?, ?, ?) " +
                 "ON DUPLICATE KEY UPDATE last_seen = VALUES(last_seen), username = VALUES(username)")) {
            
            for (PlayerModel p : batch) {
                stmt.setString(1, p.getUuid().toString());
                stmt.setString(2, p.getUsername());
                stmt.setTimestamp(3, p.getFirstJoin());
                stmt.setTimestamp(4, p.getLastSeen());
                stmt.addBatch();
            }
            
            stmt.executeBatch();
            return batch.size();
        } catch (SQLException e) {
            plugin.getLogger().warning("Ошибка flush players: " + e.getMessage());
            // Возвращаем в очередь при ошибке
            playerQueue.addAll(batch);
            return 0;
        }
    }

    private int flushSessions() {
        if (sessionQueue.isEmpty()) return 0;

        List<PlayerSessionModel> batch = new ArrayList<>();
        PlayerSessionModel session;
        while ((session = sessionQueue.poll()) != null && batch.size() < config.getBatchSize()) {
            batch.add(session);
        }

        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "INSERT INTO player_sessions (player_uuid, join_time, leave_time, ip_address) " +
                 "VALUES (?, ?, ?, ?)")) {
            
            for (PlayerSessionModel s : batch) {
                stmt.setString(1, s.getPlayerUuid().toString());
                stmt.setTimestamp(2, s.getJoinTime());
                stmt.setTimestamp(3, s.getLeaveTime());
                stmt.setString(4, s.getIpAddress());
                stmt.addBatch();
            }
            
            stmt.executeBatch();
            return batch.size();
        } catch (SQLException e) {
            plugin.getLogger().warning("Ошибка flush sessions: " + e.getMessage());
            sessionQueue.addAll(batch);
            return 0;
        }
    }

    private int flushCommands() {
        if (commandQueue.isEmpty()) return 0;

        List<CommandModel> batch = new ArrayList<>();
        CommandModel command;
        while ((command = commandQueue.poll()) != null && batch.size() < config.getBatchSize()) {
            batch.add(command);
        }

        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "INSERT INTO commands (player_uuid, command, executed_at) VALUES (?, ?, ?)")) {
            
            for (CommandModel c : batch) {
                stmt.setString(1, c.getPlayerUuid().toString());
                stmt.setString(2, c.getCommand());
                stmt.setTimestamp(3, c.getExecutedAt());
                stmt.addBatch();
            }
            
            stmt.executeBatch();
            return batch.size();
        } catch (SQLException e) {
            plugin.getLogger().warning("Ошибка flush commands: " + e.getMessage());
            commandQueue.addAll(batch);
            return 0;
        }
    }

    private int flushChat() {
        if (chatQueue.isEmpty()) return 0;

        List<ChatMessageModel> batch = new ArrayList<>();
        ChatMessageModel chat;
        while ((chat = chatQueue.poll()) != null && batch.size() < config.getBatchSize()) {
            batch.add(chat);
        }

        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "INSERT INTO chat_messages (player_uuid, message, channel, sent_at) " +
                 "VALUES (?, ?, ?, ?)")) {
            
            for (ChatMessageModel c : batch) {
                stmt.setString(1, c.getPlayerUuid().toString());
                stmt.setString(2, c.getMessage());
                stmt.setString(3, c.getChannel());
                stmt.setTimestamp(4, c.getSentAt());
                stmt.addBatch();
            }
            
            stmt.executeBatch();
            return batch.size();
        } catch (SQLException e) {
            plugin.getLogger().warning("Ошибка flush chat: " + e.getMessage());
            chatQueue.addAll(batch);
            return 0;
        }
    }

    private int flushKills() {
        if (killQueue.isEmpty()) return 0;

        List<KillModel> batch = new ArrayList<>();
        KillModel kill;
        while ((kill = killQueue.poll()) != null && batch.size() < config.getBatchSize()) {
            batch.add(kill);
        }

        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "INSERT INTO kills (killer_uuid, victim_uuid, victim_type, weapon, world, x, y, z, killed_at) " +
                 "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
            
            for (KillModel k : batch) {
                stmt.setString(1, k.getKillerUuid().toString());
                stmt.setString(2, k.getVictimUuid() != null ? k.getVictimUuid().toString() : null);
                stmt.setString(3, k.getVictimType().name());
                stmt.setString(4, k.getWeapon());
                stmt.setString(5, k.getWorld());
                stmt.setDouble(6, k.getX());
                stmt.setDouble(7, k.getY());
                stmt.setDouble(8, k.getZ());
                stmt.setTimestamp(9, k.getKilledAt());
                stmt.addBatch();
            }
            
            stmt.executeBatch();
            return batch.size();
        } catch (SQLException e) {
            plugin.getLogger().warning("Ошибка flush kills: " + e.getMessage());
            killQueue.addAll(batch);
            return 0;
        }
    }

    private int flushExploits() {
        if (exploitQueue.isEmpty()) return 0;

        List<ExploitModel> batch = new ArrayList<>();
        ExploitModel exploit;
        while ((exploit = exploitQueue.poll()) != null && batch.size() < config.getBatchSize()) {
            batch.add(exploit);
        }

        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "INSERT INTO exploits (player_uuid, exploit_type, details, severity, detected_at) " +
                 "VALUES (?, ?, ?, ?, ?)")) {
            
            for (ExploitModel e : batch) {
                stmt.setString(1, e.getPlayerUuid().toString());
                stmt.setString(2, e.getExploitType());
                stmt.setString(3, e.getDetails());
                stmt.setString(4, e.getSeverity().name());
                stmt.setTimestamp(5, e.getDetectedAt());
                stmt.addBatch();
            }
            
            stmt.executeBatch();
            return batch.size();
        } catch (SQLException e) {
            plugin.getLogger().warning("Ошибка flush exploits: " + e.getMessage());
            exploitQueue.addAll(batch);
            return 0;
        }
    }

    public int getQueueSize() {
        return playerQueue.size() + sessionQueue.size() + commandQueue.size() + 
               chatQueue.size() + killQueue.size() + exploitQueue.size();
    }

    public int getTotalProcessed() {
        return totalProcessed.get();
    }
}

