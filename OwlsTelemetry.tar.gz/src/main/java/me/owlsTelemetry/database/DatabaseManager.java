package me.owlsTelemetry.database;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import me.owlsTelemetry.OwlsTelemetry;
import me.owlsTelemetry.config.ConfigManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;

/**
 * Высокопроизводительный менеджер базы данных с HikariCP
 */
public class DatabaseManager {
    private final OwlsTelemetry plugin;
    private final ConfigManager config;
    private HikariDataSource dataSource;

    public DatabaseManager(OwlsTelemetry plugin, ConfigManager config) {
        this.plugin = plugin;
        this.config = config;
    }

    /**
     * Инициализация connection pool
     */
    public void initialize() {
        try {
            setupHikariCP();
            createTables();
            plugin.getLogger().info("DatabaseManager успешно инициализирован");
        } catch (Exception e) {
            plugin.getLogger().severe("Ошибка инициализации БД: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Настройка HikariCP - самого быстрого connection pool для Java
     */
    private void setupHikariCP() {
        HikariConfig hikariConfig = new HikariConfig();
        
        // JDBC URL
        String jdbcUrl = String.format(
            "jdbc:%s://%s:%d/%s?useSSL=false&serverTimezone=UTC&characterEncoding=utf8",
            config.getDatabaseType(),
            config.getDatabaseHost(),
            config.getDatabasePort(),
            config.getDatabaseName()
        );
        
        hikariConfig.setJdbcUrl(jdbcUrl);
        hikariConfig.setUsername(config.getDatabaseUsername());
        hikariConfig.setPassword(config.getDatabasePassword());
        
        // Оптимизация производительности
        hikariConfig.setMaximumPoolSize(config.getDatabaseMaxPoolSize());
        hikariConfig.setMinimumIdle(config.getDatabaseMinIdle());
        hikariConfig.setMaxLifetime(config.getDatabaseMaxLifetime());
        hikariConfig.setConnectionTimeout(config.getDatabaseConnectionTimeout());
        
        // Дополнительные настройки
        hikariConfig.setPoolName("OwlsTelemetry-Pool");
        hikariConfig.addDataSourceProperty("cachePrepStmts", "true");
        hikariConfig.addDataSourceProperty("prepStmtCacheSize", "250");
        hikariConfig.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
        hikariConfig.addDataSourceProperty("useServerPrepStmts", "true");
        hikariConfig.addDataSourceProperty("useLocalSessionState", "true");
        hikariConfig.addDataSourceProperty("rewriteBatchedStatements", "true");
        hikariConfig.addDataSourceProperty("cacheResultSetMetadata", "true");
        hikariConfig.addDataSourceProperty("cacheServerConfiguration", "true");
        hikariConfig.addDataSourceProperty("elideSetAutoCommits", "true");
        hikariConfig.addDataSourceProperty("maintainTimeStats", "false");
        
        this.dataSource = new HikariDataSource(hikariConfig);
        
        plugin.getLogger().info("HikariCP Connection Pool создан успешно");
    }

    /**
     * Создание таблиц в базе данных
     */
    private void createTables() throws SQLException {
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
            
            // Таблица игроков
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS players (
                    uuid VARCHAR(36) PRIMARY KEY,
                    username VARCHAR(16) NOT NULL,
                    first_join TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_username (username),
                    INDEX idx_last_seen (last_seen)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            """);
            
            // Таблица сессий
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS player_sessions (
                    id BIGINT AUTO_INCREMENT PRIMARY KEY,
                    player_uuid VARCHAR(36) NOT NULL,
                    join_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    leave_time TIMESTAMP NULL,
                    ip_address VARCHAR(45) NOT NULL,
                    INDEX idx_player (player_uuid),
                    INDEX idx_join_time (join_time),
                    FOREIGN KEY (player_uuid) REFERENCES players(uuid) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            """);
            
            // Таблица команд
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS commands (
                    id BIGINT AUTO_INCREMENT PRIMARY KEY,
                    player_uuid VARCHAR(36) NOT NULL,
                    command TEXT NOT NULL,
                    executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_player (player_uuid),
                    INDEX idx_executed_at (executed_at),
                    FOREIGN KEY (player_uuid) REFERENCES players(uuid) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            """);
            
            // Таблица чата
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS chat_messages (
                    id BIGINT AUTO_INCREMENT PRIMARY KEY,
                    player_uuid VARCHAR(36) NOT NULL,
                    message TEXT NOT NULL,
                    channel VARCHAR(64) NOT NULL DEFAULT 'global',
                    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_player (player_uuid),
                    INDEX idx_sent_at (sent_at),
                    INDEX idx_channel (channel),
                    FOREIGN KEY (player_uuid) REFERENCES players(uuid) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            """);
            
            // Таблица убийств
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS kills (
                    id BIGINT AUTO_INCREMENT PRIMARY KEY,
                    killer_uuid VARCHAR(36) NOT NULL,
                    victim_uuid VARCHAR(36) NULL,
                    victim_type ENUM('PLAYER', 'MOB') NOT NULL,
                    weapon VARCHAR(64) NOT NULL,
                    world VARCHAR(64) NOT NULL,
                    x DOUBLE NOT NULL,
                    y DOUBLE NOT NULL,
                    z DOUBLE NOT NULL,
                    killed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_killer (killer_uuid),
                    INDEX idx_victim (victim_uuid),
                    INDEX idx_killed_at (killed_at),
                    FOREIGN KEY (killer_uuid) REFERENCES players(uuid) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            """);
            
            // Таблица эксплоитов
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS exploits (
                    id BIGINT AUTO_INCREMENT PRIMARY KEY,
                    player_uuid VARCHAR(36) NOT NULL,
                    exploit_type VARCHAR(64) NOT NULL,
                    details TEXT,
                    severity ENUM('LOW', 'MEDIUM', 'HIGH', 'CRITICAL') NOT NULL,
                    detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_player (player_uuid),
                    INDEX idx_type (exploit_type),
                    INDEX idx_severity (severity),
                    INDEX idx_detected_at (detected_at),
                    FOREIGN KEY (player_uuid) REFERENCES players(uuid) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            """);
            
            plugin.getLogger().info("Таблицы базы данных созданы/проверены");
        }
    }

    /**
     * Получить соединение из пула
     */
    public Connection getConnection() throws SQLException {
        if (dataSource == null || dataSource.isClosed()) {
            throw new SQLException("DataSource не инициализирован");
        }
        return dataSource.getConnection();
    }

    /**
     * Закрыть connection pool
     */
    public void shutdown() {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
            plugin.getLogger().info("DatabaseManager остановлен");
        }
    }

    /**
     * Проверка подключения
     */
    public boolean testConnection() {
        try (Connection conn = getConnection()) {
            return conn.isValid(5);
        } catch (SQLException e) {
            plugin.getLogger().log(Level.WARNING, "Ошибка проверки подключения", e);
            return false;
        }
    }

    /**
     * Получить статистику пула
     */
    public String getPoolStats() {
        if (dataSource == null) return "N/A";
        return String.format(
            "Active: %d, Idle: %d, Waiting: %d, Total: %d",
            dataSource.getHikariPoolMXBean().getActiveConnections(),
            dataSource.getHikariPoolMXBean().getIdleConnections(),
            dataSource.getHikariPoolMXBean().getThreadsAwaitingConnection(),
            dataSource.getHikariPoolMXBean().getTotalConnections()
        );
    }
}

