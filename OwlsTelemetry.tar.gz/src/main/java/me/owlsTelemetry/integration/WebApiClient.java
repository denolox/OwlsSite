package me.owlsTelemetry.integration;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import me.owlsTelemetry.OwlsTelemetry;
import org.bukkit.Bukkit;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * Клиент для интеграции с веб-API
 * Отправляет данные от плагина на backend
 */
public class WebApiClient {
    
    private final OwlsTelemetry plugin;
    private final HttpClient httpClient;
    private final Gson gson;
    private final String apiBaseUrl;
    private final boolean enabled;
    
    public WebApiClient(OwlsTelemetry plugin) {
        this.plugin = plugin;
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .build();
        this.gson = new Gson();
        this.apiBaseUrl = plugin.getConfigManager().getWebApiUrl();
        this.enabled = plugin.getConfigManager().isWebApiEnabled();
    }
    
    /**
     * Отправка события входа игрока
     */
    public void sendPlayerJoin(String playerName, UUID playerUuid) {
        if (!enabled) return;
        
        Map<String, Object> data = new HashMap<>();
        data.put("playerName", playerName);
        data.put("playerUuid", playerUuid.toString());
        
        sendAsyncRequest("/plugin/player-join", data);
    }
    
    /**
     * Отправка события выхода игрока
     */
    public void sendPlayerQuit(UUID playerUuid) {
        if (!enabled) return;
        
        Map<String, Object> data = new HashMap<>();
        data.put("playerUuid", playerUuid.toString());
        
        sendAsyncRequest("/plugin/player-quit", data);
    }
    
    /**
     * Отправка события выполнения команды
     */
    public void sendCommandExecuted(String playerName, UUID playerUuid, String command) {
        if (!enabled) return;
        
        Map<String, Object> data = new HashMap<>();
        data.put("playerName", playerName);
        data.put("playerUuid", playerUuid.toString());
        data.put("command", command);
        
        sendAsyncRequest("/plugin/command-executed", data);
    }
    
    /**
     * Отправка события убийства
     */
    public void sendPlayerKill(String killerName, UUID killerUuid, String victimName, UUID victimUuid) {
        if (!enabled) return;
        
        Map<String, Object> data = new HashMap<>();
        data.put("killerName", killerName);
        data.put("killerUuid", killerUuid.toString());
        data.put("victimName", victimName);
        data.put("victimUuid", victimUuid.toString());
        
        sendAsyncRequest("/plugin/player-kill", data);
    }
    
    /**
     * Отправка события чата
     */
    public void sendChatMessage(String playerName, UUID playerUuid, String message) {
        if (!enabled) return;
        
        Map<String, Object> data = new HashMap<>();
        data.put("playerName", playerName);
        data.put("playerUuid", playerUuid.toString());
        data.put("message", message);
        
        sendAsyncRequest("/plugin/chat-message", data);
    }
    
    /**
     * Асинхронная отправка запроса
     */
    private void sendAsyncRequest(String endpoint, Map<String, Object> data) {
        CompletableFuture.runAsync(() -> {
            try {
                String json = gson.toJson(data);
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(apiBaseUrl + endpoint))
                        .header("Content-Type", "application/json")
                        .POST(HttpRequest.BodyPublishers.ofString(json))
                        .timeout(Duration.ofSeconds(5))
                        .build();
                
                HttpResponse<String> response = httpClient.send(request, 
                    HttpResponse.BodyHandlers.ofString());
                
                if (response.statusCode() >= 200 && response.statusCode() < 300) {
                    plugin.getLogger().fine("API request sent successfully: " + endpoint);
                } else {
                    plugin.getLogger().warning("API request failed: " + response.statusCode() + 
                        " - " + response.body());
                }
                
            } catch (IOException | InterruptedException e) {
                plugin.getLogger().warning("Failed to send API request to " + endpoint + ": " + e.getMessage());
            }
        });
    }
    
    /**
     * Проверка доступности API
     */
    public boolean testConnection() {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(apiBaseUrl + "/plugin/test"))
                    .GET()
                    .timeout(Duration.ofSeconds(5))
                    .build();
            
            HttpResponse<String> response = httpClient.send(request, 
                HttpResponse.BodyHandlers.ofString());
            
            return response.statusCode() == 200;
            
        } catch (Exception e) {
            plugin.getLogger().warning("API connection test failed: " + e.getMessage());
            return false;
        }
    }
}
