package me.owlsTelemetry.output;

import me.owlsTelemetry.OwlsTelemetry;
import me.owlsTelemetry.config.ConfigManager;
import org.bukkit.Bukkit;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Упрощенный OutputManager для Discord alerts
 */
public class OutputManager {
    private final OwlsTelemetry plugin;
    private final ConfigManager config;

    public OutputManager(OwlsTelemetry plugin, ConfigManager config) {
        this.plugin = plugin;
        this.config = config;
    }

    public void sendDiscordAlert(String title, String message) {
        if (!config.isDiscordEnabled()) return;
        
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                URL url = new URL(config.getDiscordWebhookUrl());
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                
                try {
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setDoOutput(true);
                    
                    String json = String.format(
                        "{\"embeds\":[{\"title\":\"%s\",\"description\":\"%s\",\"color\":16711680}]}",
                        title.replace("\"", "\\\""), 
                        message.replace("\"", "\\\"").replace("\n", "\\n")
                    );
                    
                    byte[] out = json.getBytes(StandardCharsets.UTF_8);
                    
                    try (OutputStream os = conn.getOutputStream()) {
                        os.write(out);
                    }
                    
                    int responseCode = conn.getResponseCode();
                    if (responseCode != 204 && responseCode != 200) {
                        plugin.getLogger().warning("Discord webhook вернул код: " + responseCode);
                    }
                } finally {
                    conn.disconnect();
                }
            } catch (Exception e) {
                plugin.getLogger().warning("Ошибка отправки Discord alert: " + e.getMessage());
            }
        });
    }
}
