package me.owlsTelemetry.config;

import me.owlsTelemetry.OwlsTelemetry;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.List;

/**
 * Управление конфигурацией плагина v2.0
 */
public class ConfigManager {
    private final OwlsTelemetry plugin;
    private FileConfiguration config;

    public ConfigManager(OwlsTelemetry plugin) {
        this.plugin = plugin;
        loadConfig();
    }

    public void loadConfig() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        this.config = plugin.getConfig();
    }

    public void reloadConfig() {
        plugin.reloadConfig();
        this.config = plugin.getConfig();
    }

    // === DATABASE ===
    public String getDatabaseType() { return config.getString("database.type", "mysql"); }
    public String getDatabaseHost() { return config.getString("database.host", "localhost"); }
    public int getDatabasePort() { return config.getInt("database.port", 3306); }
    public String getDatabaseName() { return config.getString("database.database", "owlstelemetry"); }
    public String getDatabaseUsername() { return config.getString("database.username", "root"); }
    public String getDatabasePassword() { return config.getString("database.password", ""); }
    
    public int getDatabaseMaxPoolSize() { return config.getInt("database.pool.maximum-pool-size", 10); }
    public int getDatabaseMinIdle() { return config.getInt("database.pool.minimum-idle", 2); }
    public long getDatabaseMaxLifetime() { return config.getLong("database.pool.max-lifetime", 1800000); }
    public long getDatabaseConnectionTimeout() { return config.getLong("database.pool.connection-timeout", 10000); }
    
    public boolean isBatchEnabled() { return config.getBoolean("database.batch.enabled", true); }
    public int getBatchSize() { return config.getInt("database.batch.size", 100); }
    public int getBatchFlushInterval() { return config.getInt("database.batch.flush-interval", 30); }

    // === TRACKING ===
    public boolean isTrackingConnections() { return config.getBoolean("tracking.connections", true); }
    public boolean isTrackingKills() { return config.getBoolean("tracking.kills", true); }
    public boolean isTrackingCommands() { return config.getBoolean("tracking.commands", true); }
    public boolean isTrackingChat() { return config.getBoolean("tracking.chat", true); }
    public boolean isTrackingCrashExploits() { return config.getBoolean("tracking.crash-exploits", true); }

    // === ANTI-CRASH ===
    public boolean isAntiCrashEnabled() { return config.getBoolean("anti-crash.enabled", true); }
    
    public boolean isCommandSpamEnabled() { return config.getBoolean("anti-crash.command-spam.enabled", true); }
    public int getCommandSpamMaxPerSecond() { return config.getInt("anti-crash.command-spam.max-per-second", 20); }
    public int getCommandSpamBlockDuration() { return config.getInt("anti-crash.command-spam.block-duration", 30); }
    
    public boolean isChatFloodEnabled() { return config.getBoolean("anti-crash.chat-flood.enabled", true); }
    public int getChatFloodMaxPerSecond() { return config.getInt("anti-crash.chat-flood.max-per-second", 10); }
    public int getChatFloodMuteDuration() { return config.getInt("anti-crash.chat-flood.mute-duration", 300); }
    
    public boolean isPacketFloodEnabled() { return config.getBoolean("anti-crash.packet-flood.enabled", true); }
    public int getPacketFloodMaxPerSecond() { return config.getInt("anti-crash.packet-flood.max-per-second", 1000); }
    public String getPacketFloodAction() { return config.getString("anti-crash.packet-flood.action", "kick"); }
    
    public boolean isConnectionFloodEnabled() { return config.getBoolean("anti-crash.connection-flood.enabled", true); }
    public int getConnectionFloodMaxPerSecond() { return config.getInt("anti-crash.connection-flood.max-per-second", 5); }
    public int getConnectionFloodBlockDuration() { return config.getInt("anti-crash.connection-flood.block-duration", 3600); }
    
    public boolean isMemoryMonitorEnabled() { return config.getBoolean("anti-crash.memory-monitor.enabled", true); }
    public int getMemoryMonitorCheckInterval() { return config.getInt("anti-crash.memory-monitor.check-interval", 60); }
    public int getMemoryMonitorWarningThreshold() { return config.getInt("anti-crash.memory-monitor.warning-threshold", 256); }

    // === DISCORD ===
    public boolean isDiscordEnabled() { return config.getBoolean("discord.enabled", false); }
    public String getDiscordWebhookUrl() { return config.getString("discord.webhook-url", ""); }
    public List<String> getDiscordSendEvents() { return config.getStringList("discord.send-events"); }

    // === WEB DASHBOARD ===
    public boolean isWebSocketEnabled() { return config.getBoolean("web-dashboard.websocket.enabled", true); }
    public int getWebSocketPort() { return config.getInt("web-dashboard.websocket.port", 8081); }
    public String getJwtSecret() { return config.getString("web-dashboard.jwt-secret", ""); }
    public List<String> getApiWhitelist() { return config.getStringList("web-dashboard.api.whitelist"); }
    
    // === WEB API INTEGRATION ===
    public boolean isWebApiEnabled() { return config.getBoolean("web-api.enabled", true); }
    public String getWebApiUrl() { return config.getString("web-api.url", "http://localhost:8081/api"); }
    public int getWebApiTimeout() { return config.getInt("web-api.timeout", 5000); }
    public boolean isWebApiRetryEnabled() { return config.getBoolean("web-api.retry.enabled", true); }
    public int getWebApiRetryAttempts() { return config.getInt("web-api.retry.attempts", 3); }

    // === PERFORMANCE ===
    public boolean isAsyncProcessing() { return config.getBoolean("performance.async-processing", true); }
    public int getEventQueueSize() { return config.getInt("performance.event-queue-size", 10000); }
    public int getWorkerThreads() { return config.getInt("performance.worker-threads", 4); }
    
    public boolean isAutoCleanupEnabled() { return config.getBoolean("performance.auto-cleanup.enabled", true); }
    public int getAutoCleanupKeepDays() { return config.getInt("performance.auto-cleanup.keep-days", 30); }
    public int getAutoCleanupCheckInterval() { return config.getInt("performance.auto-cleanup.check-interval", 24); }

    // === DEBUG ===
    public boolean isDebugEnabled() { return config.getBoolean("debug.enabled", false); }
    public boolean isLogSql() { return config.getBoolean("debug.log-sql", false); }
    public boolean isLogPerformance() { return config.getBoolean("debug.log-performance", true); }

    public FileConfiguration getRawConfig() { return config; }
}
