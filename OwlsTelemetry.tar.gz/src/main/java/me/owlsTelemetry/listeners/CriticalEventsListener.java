package me.owlsTelemetry.listeners;

import me.owlsTelemetry.OwlsTelemetry;
import me.owlsTelemetry.config.ConfigManager;
import me.owlsTelemetry.database.BatchProcessor;
import me.owlsTelemetry.database.models.*;
import me.owlsTelemetry.protection.CrashExploitDetector;
import me.owlsTelemetry.integration.WebApiClient;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.*;

import java.net.InetSocketAddress;
import java.sql.Timestamp;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Единый оптимизированный Listener для всех критических событий
 * Минимальные накладные расходы, максимальная производительность
 */
public class CriticalEventsListener implements Listener {
    private final OwlsTelemetry plugin;
    private final ConfigManager config;
    private final BatchProcessor batchProcessor;
    private final CrashExploitDetector crashDetector;
    private final WebApiClient webApiClient;
    
    // Кеш активных сессий
    private final Map<UUID, PlayerSessionModel> activeSessions = new ConcurrentHashMap<>();

    public CriticalEventsListener(OwlsTelemetry plugin, ConfigManager config, 
                                  BatchProcessor batchProcessor, CrashExploitDetector crashDetector) {
        this.plugin = plugin;
        this.config = config;
        this.batchProcessor = batchProcessor;
        this.crashDetector = crashDetector;
        this.webApiClient = new WebApiClient(plugin);
    }

    // === CONNECTIONS ===
    
    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerJoin(PlayerJoinEvent event) {
        if (!config.isTrackingConnections()) return;
        
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        Timestamp now = new Timestamp(System.currentTimeMillis());
        
        // Проверка Connection Flood
        InetSocketAddress address = player.getAddress();
        if (address != null && config.isTrackingCrashExploits()) {
            String ip = address.getAddress().getHostAddress();
            if (crashDetector.checkConnectionFlood(ip)) {
                player.kick(net.kyori.adventure.text.Component.text("§c[AntiCrash] Connection Flood Protection"));
                return;
            }
        }
        
        // Обновляем/создаём игрока
        PlayerModel playerModel = new PlayerModel(uuid, player.getName());
        batchProcessor.addPlayer(playerModel);
        
        // Создаём сессию
        String ip = address != null ? address.getAddress().getHostAddress() : "unknown";
        PlayerSessionModel session = new PlayerSessionModel(uuid, now, ip);
        activeSessions.put(uuid, session);
        
        // Отправка в веб-API
        webApiClient.sendPlayerJoin(player.getName(), uuid);
        
        if (config.isDebugEnabled()) {
            plugin.getLogger().info(String.format("[JOIN] %s (%s)", player.getName(), ip));
        }
    }
    
    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerQuit(PlayerQuitEvent event) {
        if (!config.isTrackingConnections()) return;
        
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        
        // Обновляем last_seen
        PlayerModel playerModel = new PlayerModel(uuid, player.getName());
        playerModel.setLastSeen(new Timestamp(System.currentTimeMillis()));
        batchProcessor.addPlayer(playerModel);
        
        // Завершаем сессию
        PlayerSessionModel session = activeSessions.remove(uuid);
        if (session != null) {
            session.setLeaveTime(new Timestamp(System.currentTimeMillis()));
            batchProcessor.addSession(session);
            
            if (config.isDebugEnabled()) {
                plugin.getLogger().info(String.format("[QUIT] %s (сессия: %.1f мин)", 
                    player.getName(), session.getDuration() / 60000.0));
            }
        }
        
        // Отправка в веб-API
        webApiClient.sendPlayerQuit(uuid);
        
        // Очистка данных детектора
        crashDetector.clearPlayerData(uuid);
    }
    
    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerKick(PlayerKickEvent event) {
        // Обрабатываем как quit
        if (!event.isCancelled()) {
            Player player = event.getPlayer();
            UUID uuid = player.getUniqueId();
            
            if (!config.isTrackingConnections()) return;
            
            // Обновляем last_seen
            PlayerModel playerModel = new PlayerModel(uuid, player.getName());
            playerModel.setLastSeen(new Timestamp(System.currentTimeMillis()));
            batchProcessor.addPlayer(playerModel);
            
            // Завершаем сессию
            PlayerSessionModel session = activeSessions.remove(uuid);
            if (session != null) {
                session.setLeaveTime(new Timestamp(System.currentTimeMillis()));
                batchProcessor.addSession(session);
            }
            
            // Очистка данных детектора
            crashDetector.clearPlayerData(uuid);
        }
    }

    // === KILLS ===
    
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerDeath(PlayerDeathEvent event) {
        if (!config.isTrackingKills()) return;
        
        Player victim = event.getPlayer();
        Player killer = victim.getKiller();
        
        if (killer == null) return; // Только PvP
        
        String weapon = killer.getInventory().getItemInMainHand().getType().name();
        
        KillModel kill = new KillModel(
            killer.getUniqueId(),
            victim.getUniqueId(),
            KillModel.VictimType.PLAYER,
            weapon,
            victim.getWorld().getName(),
            victim.getLocation().getX(),
            victim.getLocation().getY(),
            victim.getLocation().getZ()
        );
        
        batchProcessor.addKill(kill);
        
        // Отправка в веб-API
        webApiClient.sendPlayerKill(killer.getName(), killer.getUniqueId(), 
            victim.getName(), victim.getUniqueId());
        
        if (config.isDebugEnabled()) {
            plugin.getLogger().info(String.format("[PVP] %s убил %s (%s)", 
                killer.getName(), victim.getName(), weapon));
        }
    }
    
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityDeath(EntityDeathEvent event) {
        if (!config.isTrackingKills()) return;
        
        LivingEntity entity = event.getEntity();
        Player killer = entity.getKiller();
        
        if (killer == null || entity instanceof Player) return; // Только PvE
        
        String weapon = killer.getInventory().getItemInMainHand().getType().name();
        
        KillModel kill = new KillModel(
            killer.getUniqueId(),
            null, // Мобы не имеют UUID
            KillModel.VictimType.MOB,
            weapon,
            entity.getWorld().getName(),
            entity.getLocation().getX(),
            entity.getLocation().getY(),
            entity.getLocation().getZ()
        );
        
        batchProcessor.addKill(kill);
    }

    // === COMMANDS ===
    
    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
        if (!config.isTrackingCommands() && !config.isTrackingCrashExploits()) return;
        
        Player player = event.getPlayer();
        String fullCommand = event.getMessage().substring(1); // Убираем /
        
        // Проверка Command Spam
        if (config.isTrackingCrashExploits() && crashDetector.checkCommandSpam(player)) {
            event.setCancelled(true);
            return;
        }
        
        // Логируем команду
        if (config.isTrackingCommands()) {
            CommandModel command = new CommandModel(player.getUniqueId(), fullCommand);
            batchProcessor.addCommand(command);
            
            // Отправка в веб-API
            webApiClient.sendCommandExecuted(player.getName(), player.getUniqueId(), fullCommand);
            
            if (config.isDebugEnabled()) {
                plugin.getLogger().info(String.format("[CMD] %s: /%s", player.getName(), fullCommand));
            }
        }
    }

    // === CHAT ===
    
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onAsyncPlayerChat(AsyncPlayerChatEvent event) {
        if (!config.isTrackingChat() && !config.isTrackingCrashExploits()) return;
        
        Player player = event.getPlayer();
        String message = event.getMessage();
        
        // Проверка Chat Flood
        if (config.isTrackingCrashExploits() && crashDetector.checkChatFlood(player)) {
            event.setCancelled(true);
            return;
        }
        
        // Логируем сообщение
        if (config.isTrackingChat()) {
            ChatMessageModel chat = new ChatMessageModel(
                player.getUniqueId(),
                message,
                "global" // Можно расширить для разных каналов
            );
            
            batchProcessor.addChat(chat);
            
            // Отправка в веб-API
            webApiClient.sendChatMessage(player.getName(), player.getUniqueId(), message);
            
            if (config.isDebugEnabled()) {
                plugin.getLogger().info(String.format("[CHAT] %s: %s", player.getName(), message));
            }
        }
    }

    /**
     * Flush всех активных сессий при выключении плагина
     */
    public void flushActiveSessions() {
        Timestamp now = new Timestamp(System.currentTimeMillis());
        
        for (PlayerSessionModel session : activeSessions.values()) {
            session.setLeaveTime(now);
            batchProcessor.addSession(session);
        }
        
        activeSessions.clear();
        plugin.getLogger().info("Активные сессии сохранены");
    }
}

