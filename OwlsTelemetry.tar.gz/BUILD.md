# Инструкция по сборке OwlsTelemetry

## 🔧 Требования

- **Java**: JDK 21 или выше
- **Maven**: 3.6.0 или выше
- **Server**: Paper 1.20.6

## 📦 Сборка плагина

### Из командной строки

```bash
# Перейти в директорию проекта
cd /home/clanember/IdeaProjects/OwlsTelemetry

# Сборка с помощью Maven
mvn clean package

# Результат будет в target/OwlsTelemetry-1.0.jar
```

### Из IntelliJ IDEA

1. Откройте проект в IntelliJ IDEA
2. Откройте Maven панель (View → Tool Windows → Maven)
3. Разверните Lifecycle
4. Дважды кликните на `package`
5. JAR файл будет создан в папке `target/`

## 🚀 Установка на сервер

1. Скопируйте `OwlsTelemetry-1.0.jar` в папку `plugins/` вашего Paper сервера
2. Запустите сервер
3. Остановите сервер
4. Настройте `plugins/OwlsTelemetry/config.yml`
5. Запустите сервер снова

## 📁 Структура проекта

```
OwlsTelemetry/
├── src/
│   └── main/
│       ├── java/
│       │   └── me/owlsTelemetry/
│       │       ├── commands/
│       │       │   └── TelemetryCommand.java
│       │       ├── config/
│       │       │   └── ConfigManager.java
│       │       ├── detection/
│       │       │   ├── ExploitDetector.java
│       │       │   └── PlayerViolationTracker.java
│       │       ├── listeners/
│       │       │   ├── BlockListener.java
│       │       │   ├── EntityListener.java
│       │       │   ├── ItemListener.java
│       │       │   └── PlayerListener.java
│       │       ├── model/
│       │       │   ├── events/
│       │       │   │   ├── BlockEvent.java
│       │       │   │   ├── ChatEvent.java
│       │       │   │   ├── CommandEvent.java
│       │       │   │   ├── EntityEvent.java
│       │       │   │   ├── ExploitAlertEvent.java
│       │       │   │   ├── GameplayEvent.java
│       │       │   │   ├── ItemEvent.java
│       │       │   │   └── PlayerConnectionEvent.java
│       │       │   ├── LocationData.java
│       │       │   └── TelemetryEvent.java
│       │       ├── output/
│       │       │   ├── DiscordWebhook.java
│       │       │   ├── EventLogger.java
│       │       │   └── OutputManager.java
│       │       ├── service/
│       │       │   └── DataService.java
│       │       └── OwlsTelemetry.java
│       └── resources/
│           ├── config.yml
│           └── plugin.yml
├── pom.xml
├── README.md
├── API_EXAMPLES.md
├── BUILD.md
└── .gitignore
```

## 🧪 Тестирование

### Локальное тестирование

1. Создайте тестовый Paper сервер:
```bash
mkdir test-server
cd test-server
# Скачайте Paper 1.20.6
wget https://api.papermc.io/v2/projects/paper/versions/1.20.6/builds/latest/downloads/paper-1.20.6-R0.1-SNAPSHOT.jar -O paper.jar
```

2. Скопируйте собранный плагин:
```bash
cp ../target/OwlsTelemetry-1.0.jar plugins/
```

3. Запустите сервер:
```bash
java -Xmx2G -Xms2G -jar paper.jar --nogui
```

### Проверка функциональности

После запуска сервера проверьте:

1. **Загрузка плагина**:
   - В консоли должно появиться сообщение "OwlsTelemetry успешно загружен!"
   
2. **Создание конфига**:
   - Файл `plugins/OwlsTelemetry/config.yml` должен быть создан
   
3. **Команды**:
   ```
   /owlstelemetry help
   /owlstelemetry stats
   ```

4. **Логирование**:
   - Выполните несколько действий в игре (разбейте блоки, походите)
   - Проверьте папку `plugins/OwlsTelemetry/logs/`
   - Должны появиться `.jsonl` файлы с событиями

5. **Discord** (если настроен):
   - Зайдите на сервер
   - В Discord канале должно появиться уведомление

## 🐛 Отладка

### Включение режима отладки

В `config.yml`:
```yaml
debug: true
```

Это выведет дополнительную информацию в консоль сервера.

### Проверка логов

Логи сохраняются в формате JSONL. Для просмотра:

```bash
# Последние 10 событий
tail -n 10 plugins/OwlsTelemetry/logs/telemetry_*.jsonl

# Красивый вывод с jq
tail -n 10 plugins/OwlsTelemetry/logs/telemetry_*.jsonl | jq .
```

### Частые проблемы

1. **Плагин не загружается**:
   - Проверьте версию Java (должна быть 21+)
   - Проверьте версию Paper (должна быть 1.20.6)
   - Проверьте логи сервера на ошибки

2. **Discord webhooks не работают**:
   - Проверьте правильность URL вебхука
   - Убедитесь, что URL не равен "https://discord.com/api/webhooks/..."
   - Проверьте права вебхука в Discord

3. **Логи не создаются**:
   - Проверьте права доступа к папке плагина
   - Убедитесь, что `async_logging: true` в конфиге
   - Проверьте, включены ли нужные модули tracking

## 📊 Производительность

### Рекомендуемые настройки для разных размеров серверов

**Малый сервер (< 20 игроков)**:
```yaml
tracking:
  blocks: true
  entities: true
  chat: true
  commands: true
  movement: true  # Можно включить
  items: true
  gameplay: true
  connections: true
```

**Средний сервер (20-100 игроков)**:
```yaml
tracking:
  blocks: true
  entities: true
  chat: true
  commands: true
  movement: false  # Отключить для производительности
  items: true
  gameplay: true
  connections: true
```

**Большой сервер (> 100 игроков)**:
```yaml
tracking:
  blocks: true
  entities: false  # Можно отключить
  chat: false      # Можно отключить
  commands: true
  movement: false
  items: false
  gameplay: true
  connections: true

storage:
  max_file_size_mb: 50  # Меньший размер для частой ротации
```

## 🔄 Обновление

1. Остановите сервер
2. Замените старый JAR файл новым в папке `plugins/`
3. Запустите сервер
4. Если изменился формат конфига, проверьте `config.yml`

## 📦 Зависимости

Плагин включает все зависимости в JAR файл (shade plugin):
- Gson 2.10.1
- JetBrains Annotations 24.0.1

Опциональные зависимости:
- ProtocolLib (для расширенного трекинга трафика)

## 🎯 Готово!

После успешной сборки и тестирования ваш плагин готов к использованию на продакшн сервере.

Для получения помощи:
- Прочитайте [README.md](README.md)
- Изучите [API_EXAMPLES.md](API_EXAMPLES.md)
- Создайте issue на GitHub

