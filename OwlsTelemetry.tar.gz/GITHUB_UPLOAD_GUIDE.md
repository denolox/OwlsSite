# 🚀 OwlsTelemetry - Загрузка на GitHub

## 📋 **Пошаговая инструкция:**

### **Шаг 1: Создание репозитория на GitHub**

1. **Зайдите на [GitHub.com](https://github.com)**
2. **Нажмите "New repository"** (зеленая кнопка)
3. **Заполните форму:**
   - **Repository name:** `OwlsTelemetry`
   - **Description:** `Minecraft Server Telemetry System with Web Dashboard`
   - **Visibility:** Public или Private (на ваш выбор)
   - **НЕ** ставьте галочки на README, .gitignore, license
4. **Нажмите "Create repository"**

### **Шаг 2: Получение URL репозитория**

После создания репозитория GitHub покажет URL, например:
```
https://github.com/yourusername/OwlsTelemetry.git
```

**Скопируйте этот URL!**

### **Шаг 3: Загрузка проекта на GitHub**

Выполните эти команды в терминале:

```bash
# Перейдите в папку проекта
cd /home/clanember/IdeaProjects/OwlsTelemetry

# Добавьте удаленный репозиторий (замените URL на ваш!)
git remote add origin https://github.com/yourusername/OwlsTelemetry.git

# Загрузите проект на GitHub
git push -u origin master
```

### **Шаг 4: Проверка загрузки**

1. **Обновите страницу репозитория на GitHub**
2. **Убедитесь, что все файлы загружены:**
   - ✅ `OtSite/` - веб-интерфейс
   - ✅ `src/` - плагин Minecraft
   - ✅ `pom.xml` - конфигурация Maven
   - ✅ `README.md` - документация

---

## 🖥️ **Шаг 5: Клонирование на VDS**

### **На вашем VDS сервере выполните:**

```bash
# Установка Git (если не установлен)
sudo apt update
sudo apt install git -y

# Клонирование проекта
git clone https://github.com/yourusername/OwlsTelemetry.git

# Переход в папку проекта
cd OwlsTelemetry

# Проверка файлов
ls -la
```

### **Структура проекта на VDS:**
```
OwlsTelemetry/
├── OtSite/                    # Веб-интерфейс
│   ├── backend/              # Spring Boot API
│   ├── final-dashboard.html  # Frontend
│   └── VDS_DEPLOYMENT_GUIDE.md
├── src/                      # Плагин Minecraft
├── pom.xml                   # Maven конфигурация
└── README.md
```

---

## 🔧 **Шаг 6: Запуск на VDS**

### **Backend (Spring Boot):**
```bash
cd OwlsTelemetry/OtSite/backend
mvn clean package -DskipTests
java -jar target/owls-telemetry-backend-2.0.0.jar
```

### **Frontend (HTML Dashboard):**
```bash
cd OwlsTelemetry/OtSite
python3 -m http.server 3001
```

### **Плагин Minecraft:**
```bash
# Сборка плагина
cd OwlsTelemetry
mvn clean package -DskipTests

# Копирование в папку plugins
cp target/OwlsTelemetry-2.0.jar /path/to/your/minecraft/server/plugins/
```

---

## 📊 **Результат:**

✅ **Проект загружен на GitHub**  
✅ **Можно клонировать на любой VDS**  
✅ **Все файлы и инструкции включены**  
✅ **Готово к продакшену!**

---

## 🎯 **Полезные команды Git:**

```bash
# Обновление проекта на VDS
git pull origin master

# Проверка статуса
git status

# Просмотр истории
git log --oneline

# Откат изменений
git checkout -- filename
```

**Теперь ваш проект доступен на GitHub и готов к развертыванию на любом VDS! 🦉**
