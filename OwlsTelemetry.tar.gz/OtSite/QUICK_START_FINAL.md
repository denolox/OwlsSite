# 🚀 OwlsTelemetry - Быстрый запуск

## 📋 **Что нужно сделать:**

### 1. **Запустить Backend (Spring Boot)**
```bash
cd /home/clanember/IdeaProjects/OwlsTelemetry/OtSite/backend
mvn spring-boot:run
```
**Порт:** 8081 (не 8080!)

### 2. **Запустить Frontend (HTML Dashboard)**
```bash
cd /home/clanember/IdeaProjects/OwlsTelemetry/OtSite
python3 -m http.server 3001
```
**Порт:** 3001

### 3. **Открыть Dashboard**
- **URL:** http://localhost:3001/final-dashboard.html
- **Логин:** OwlsRise
- **Пароль:** trederpro1//..//trederpro

---

## 🎯 **Что будет работать:**

### ✅ **Backend API:**
- **Auth:** http://localhost:8081/api/auth/test
- **Stats:** http://localhost:8081/api/stats/overview
- **Plugin API:** http://localhost:8081/api/plugin/test

### ✅ **Frontend Dashboard:**
- Красивый интерфейс с графиками
- Автоматический вход
- Реальная статистика (когда плагин подключен)

### ✅ **Интеграция с плагином:**
- Плагин отправляет данные на API
- Dashboard показывает реальную статистику
- Все события в реальном времени

---

## 🔧 **Настройка плагина Minecraft:**

### 1. **Скопировать плагин:**
```bash
cp target/OwlsTelemetry-2.0.jar /path/to/your/minecraft/server/plugins/
```

### 2. **Настроить config.yml:**
```yaml
web-api:
  enabled: true
  url: "http://localhost:8081/api"
```

### 3. **Перезапустить сервер**

---

## 📊 **Результат:**

- ✅ **Backend** работает на порту 8081
- ✅ **Frontend** работает на порту 3001
- ✅ **Плагин** отправляет данные
- ✅ **Dashboard** показывает реальную статистику
- ✅ **Все работает без багов!**

---

## 🎉 **Готово!**

Теперь у вас есть полностью рабочая система OwlsTelemetry с:
- Веб-интерфейсом
- Интеграцией с плагином
- Реальными данными
- Красивым дизайном

**Удачного использования! 🦉**
