# 🦉 OwlsTelemetry - Полная инструкция по установке на VDS Ubuntu

## 📋 **Требования к серверу:**
- **ОС:** Ubuntu 20.04+ или 22.04+
- **RAM:** Минимум 2GB (рекомендуется 4GB+)
- **CPU:** 2 ядра
- **Диск:** 20GB свободного места
- **Порты:** 8081 (backend), 3001 (frontend), 25565 (Minecraft)

---

## 🚀 **Шаг 1: Подготовка сервера**

### Обновление системы:
```bash
sudo apt update && sudo apt upgrade -y
```

### Установка необходимых пакетов:
```bash
sudo apt install -y openjdk-21-jdk maven nginx python3 python3-pip git curl wget unzip
```

### Проверка установки Java:
```bash
java -version
# Должно показать: openjdk 21.x.x
```

---

## 🔧 **Шаг 2: Настройка файрвола**

### Открытие портов:
```bash
sudo ufw allow 22      # SSH
sudo ufw allow 8081    # Backend API
sudo ufw allow 3001    # Frontend
sudo ufw allow 25565   # Minecraft
sudo ufw --force enable
```

### Проверка статуса:
```bash
sudo ufw status
```

---

## 📁 **Шаг 3: Создание структуры проекта**

### Создание директорий:
```bash
sudo mkdir -p /opt/owlstelemetry/{backend,frontend,data,logs}
sudo chown -R $USER:$USER /opt/owlstelemetry
cd /opt/owlstelemetry
```

### Копирование файлов проекта:
```bash
# Если у вас есть архив проекта:
# wget https://your-domain.com/owlstelemetry.zip
# unzip owlstelemetry.zip

# Или клонирование из Git:
# git clone https://github.com/your-repo/owlstelemetry.git .
```

---

## 🗄️ **Шаг 4: Настройка Backend (Spring Boot)**

### Переход в директорию backend:
```bash
cd /opt/owlstelemetry/backend
```

### Создание JAR файла:
```bash
mvn clean package -DskipTests
```

### Создание systemd сервиса:
```bash
sudo nano /etc/systemd/system/owlstelemetry-backend.service
```

**Содержимое файла:**
```ini
[Unit]
Description=OwlsTelemetry Backend
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/owlstelemetry/backend
ExecStart=/usr/bin/java -jar target/owls-telemetry-backend-2.0.0.jar
Restart=always
RestartSec=10
Environment=JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64

[Install]
WantedBy=multi-user.target
```

### Запуск backend:
```bash
sudo systemctl daemon-reload
sudo systemctl enable owlstelemetry-backend
sudo systemctl start owlstelemetry-backend
sudo systemctl status owlstelemetry-backend
```

---

## 🌐 **Шаг 5: Настройка Frontend**

### Создание простого HTTP сервера:
```bash
cd /opt/owlstelemetry/frontend
# Скопируйте final-dashboard.html в эту директорию
```

### Создание systemd сервиса для frontend:
```bash
sudo nano /etc/systemd/system/owlstelemetry-frontend.service
```

**Содержимое файла:**
```ini
[Unit]
Description=OwlsTelemetry Frontend
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/owlstelemetry/frontend
ExecStart=/usr/bin/python3 -m http.server 3001
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

### Запуск frontend:
```bash
sudo systemctl daemon-reload
sudo systemctl enable owlstelemetry-frontend
sudo systemctl start owlstelemetry-frontend
sudo systemctl status owlstelemetry-frontend
```

---

## 🔒 **Шаг 6: Настройка Nginx (опционально)**

### Создание конфигурации Nginx:
```bash
sudo nano /etc/nginx/sites-available/owlstelemetry
```

**Содержимое файла:**
```nginx
server {
    listen 80;
    server_name your-domain.com;  # Замените на ваш домен

    # Frontend
    location / {
        proxy_pass http://localhost:3001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    # Backend API
    location /api/ {
        proxy_pass http://localhost:8081/api/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

### Активация конфигурации:
```bash
sudo ln -s /etc/nginx/sites-available/owlstelemetry /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

---

## 🎮 **Шаг 7: Установка плагина Minecraft**

### Скачивание плагина:
```bash
cd /opt/owlstelemetry
wget https://github.com/your-repo/owls-telemetry-plugin/releases/latest/download/OwlsTelemetry.jar
```

### Копирование в папку plugins:
```bash
# Если у вас есть Minecraft сервер:
# cp OwlsTelemetry.jar /path/to/your/minecraft/server/plugins/

# Создание конфигурации плагина:
mkdir -p /opt/owlstelemetry/plugin-config
```

### Создание config.yml для плагина:
```bash
nano /opt/owlstelemetry/plugin-config/config.yml
```

**Содержимое файла:**
```yaml
# OwlsTelemetry Plugin Configuration
database:
  enabled: true
  api_url: "http://localhost:8081/api/plugin"
  
tracking:
  players: true
  commands: true
  chat: true
  kills: true
  
security:
  rate_limit: 100
  max_connections: 50
```

---

## 🔧 **Шаг 8: Настройка мониторинга**

### Создание скрипта мониторинга:
```bash
nano /opt/owlstelemetry/monitor.sh
```

**Содержимое файла:**
```bash
#!/bin/bash

# Проверка статуса сервисов
echo "=== OwlsTelemetry Status ==="
echo "Backend: $(systemctl is-active owlstelemetry-backend)"
echo "Frontend: $(systemctl is-active owlstelemetry-frontend)"
echo "Nginx: $(systemctl is-active nginx)"

# Проверка портов
echo ""
echo "=== Port Status ==="
netstat -tlnp | grep -E "(8081|3001|80)"

# Проверка логов
echo ""
echo "=== Recent Backend Logs ==="
journalctl -u owlstelemetry-backend --lines=5 --no-pager
```

### Сделать скрипт исполняемым:
```bash
chmod +x /opt/owlstelemetry/monitor.sh
```

---

## 🧪 **Шаг 9: Тестирование системы**

### Проверка backend:
```bash
curl http://localhost:8081/api/auth/test
curl http://localhost:8081/api/stats/overview
```

### Проверка frontend:
```bash
curl http://localhost:3001/final-dashboard.html
```

### Проверка через браузер:
- **Frontend:** http://your-server-ip:3001/final-dashboard.html
- **Backend API:** http://your-server-ip:8081/api/auth/test
- **H2 Console:** http://your-server-ip:8081/api/h2-console

---

## 🔐 **Шаг 10: Настройка SSL (опционально)**

### Установка Certbot:
```bash
sudo apt install certbot python3-certbot-nginx -y
```

### Получение SSL сертификата:
```bash
sudo certbot --nginx -d your-domain.com
```

---

## 📊 **Шаг 11: Настройка автоматического обновления**

### Создание скрипта обновления:
```bash
nano /opt/owlstelemetry/update.sh
```

**Содержимое файла:**
```bash
#!/bin/bash

echo "Обновление OwlsTelemetry..."

# Остановка сервисов
sudo systemctl stop owlstelemetry-backend
sudo systemctl stop owlstelemetry-frontend

# Обновление кода (если используете Git)
# cd /opt/owlstelemetry
# git pull

# Пересборка backend
cd /opt/owlstelemetry/backend
mvn clean package -DskipTests

# Запуск сервисов
sudo systemctl start owlstelemetry-backend
sudo systemctl start owlstelemetry-frontend

echo "Обновление завершено!"
```

---

## 🚨 **Устранение неполадок**

### Проверка логов:
```bash
# Backend логи
sudo journalctl -u owlstelemetry-backend -f

# Frontend логи
sudo journalctl -u owlstelemetry-frontend -f

# Nginx логи
sudo tail -f /var/log/nginx/error.log
```

### Перезапуск сервисов:
```bash
sudo systemctl restart owlstelemetry-backend
sudo systemctl restart owlstelemetry-frontend
sudo systemctl restart nginx
```

### Проверка портов:
```bash
sudo netstat -tlnp | grep -E "(8081|3001|80)"
```

---

## 📝 **Финальная проверка**

### Все должно работать:
1. ✅ **Backend** на порту 8081
2. ✅ **Frontend** на порту 3001  
3. ✅ **Nginx** на порту 80 (если настроен)
4. ✅ **Плагин Minecraft** отправляет данные
5. ✅ **Dashboard** показывает реальную статистику

### Доступ к системе:
- **Dashboard:** http://your-server-ip:3001/final-dashboard.html
- **Логин:** OwlsRise
- **Пароль:** trederpro1//..//trederpro

---

## 🎯 **Готово!**

Теперь у вас есть полностью рабочая система OwlsTelemetry на VDS с:
- ✅ Backend API на порту 8081
- ✅ Frontend Dashboard на порту 3001
- ✅ Интеграция с плагином Minecraft
- ✅ Реальная статистика игроков
- ✅ Автоматический запуск при перезагрузке сервера

**Удачного использования! 🦉**
