package me.owlsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OwlsTelemetryApplication {
    public static void main(String[] args) {
        SpringApplication.run(OwlsTelemetryApplication.class, args);
    }
}
