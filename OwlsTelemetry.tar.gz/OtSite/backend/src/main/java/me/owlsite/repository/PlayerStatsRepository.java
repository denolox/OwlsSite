package me.owlsite.repository;

import me.owlsite.model.PlayerStats;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface PlayerStatsRepository extends JpaRepository<PlayerStats, Long> {
    Optional<PlayerStats> findByPlayerUuid(String playerUuid);
    Optional<PlayerStats> findByPlayerName(String playerName);
    
    @Query("SELECT p FROM PlayerStats p WHERE p.online = true")
    List<PlayerStats> findOnlinePlayers();
    
    @Query("SELECT COUNT(p) FROM PlayerStats p WHERE p.online = true")
    int countOnlinePlayers();
    
    @Query("SELECT SUM(p.totalSessions) FROM PlayerStats p")
    Long getTotalSessions();
    
    @Query("SELECT SUM(p.totalCommands) FROM PlayerStats p")
    Long getTotalCommands();
}
