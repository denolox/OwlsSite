package me.owlsite.controller;

import me.owlsite.service.StatsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/plugin")
@CrossOrigin(origins = "*")
public class PluginController {

    @Autowired
    private StatsService statsService;

    @PostMapping("/player-join")
    public ResponseEntity<?> playerJoin(@RequestBody Map<String, Object> data) {
        String playerName = (String) data.get("playerName");
        String playerUuid = (String) data.get("playerUuid");
        
        if (playerName == null || playerUuid == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "playerName и playerUuid обязательны"));
        }
        
        statsService.updatePlayerStats(playerName, playerUuid, true);
        return ResponseEntity.ok(Map.of("message", "Игрок добавлен"));
    }

    @PostMapping("/player-quit")
    public ResponseEntity<?> playerQuit(@RequestBody Map<String, Object> data) {
        String playerUuid = (String) data.get("playerUuid");
        
        if (playerUuid == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "playerUuid обязателен"));
        }
        
        statsService.updatePlayerStats(null, playerUuid, false);
        return ResponseEntity.ok(Map.of("message", "Игрок удален"));
    }

    @PostMapping("/command-executed")
    public ResponseEntity<?> commandExecuted(@RequestBody Map<String, Object> data) {
        String playerUuid = (String) data.get("playerUuid");
        String command = (String) data.get("command");
        
        if (playerUuid == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "playerUuid обязателен"));
        }
        
        statsService.incrementCommandCount(playerUuid);
        return ResponseEntity.ok(Map.of("message", "Команда зафиксирована"));
    }

    @GetMapping("/test")
    public ResponseEntity<?> test() {
        return ResponseEntity.ok(Map.of("message", "Plugin API работает!"));
    }
}
