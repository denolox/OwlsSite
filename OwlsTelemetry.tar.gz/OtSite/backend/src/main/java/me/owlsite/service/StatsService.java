package me.owlsite.service;

import me.owlsite.model.PlayerStats;
import me.owlsite.repository.PlayerStatsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class StatsService {

    @Autowired
    private PlayerStatsRepository playerStatsRepository;

    public Map<String, Object> getOverviewStats() {
        Map<String, Object> stats = new HashMap<>();
        
        stats.put("onlinePlayers", playerStatsRepository.countOnlinePlayers());
        stats.put("totalSessions", playerStatsRepository.getTotalSessions() != null ? playerStatsRepository.getTotalSessions() : 0);
        stats.put("totalCommands", playerStatsRepository.getTotalCommands() != null ? playerStatsRepository.getTotalCommands() : 0);
        stats.put("totalExploits", 0); // Пока заглушка
        
        return stats;
    }

    public List<PlayerStats> getOnlinePlayers() {
        return playerStatsRepository.findOnlinePlayers();
    }

    public PlayerStats updatePlayerStats(String playerName, String playerUuid, boolean online) {
        Optional<PlayerStats> existing = playerStatsRepository.findByPlayerUuid(playerUuid);
        
        if (existing.isPresent()) {
            PlayerStats stats = existing.get();
            stats.setPlayerName(playerName);
            stats.setOnline(online);
            if (online) {
                stats.setTotalSessions(stats.getTotalSessions() + 1);
            }
            return playerStatsRepository.save(stats);
        } else {
            PlayerStats newStats = new PlayerStats(playerName, playerUuid);
            newStats.setOnline(online);
            if (online) {
                newStats.setTotalSessions(1);
            }
            return playerStatsRepository.save(newStats);
        }
    }

    public void incrementCommandCount(String playerUuid) {
        Optional<PlayerStats> stats = playerStatsRepository.findByPlayerUuid(playerUuid);
        if (stats.isPresent()) {
            PlayerStats playerStats = stats.get();
            playerStats.setTotalCommands(playerStats.getTotalCommands() + 1);
            playerStatsRepository.save(playerStats);
        }
    }
}
