package me.owlsite.config;

import me.owlsite.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserService userService;

    @Override
    public void run(String... args) throws Exception {
        try {
            userService.createUser("OwlsRise", "trederpro1//..//trederpro", "ADMIN");
            System.out.println("✅ Создан дефолтный пользователь: OwlsRise");
        } catch (RuntimeException e) {
            System.out.println("ℹ️  Пользователь OwlsRise уже существует");
        }
    }
}
