package me.owlsite.service;

import me.owlsite.model.User;
import me.owlsite.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public User createUser(String username, String password, String role) {
        if (userRepository.existsByUsername(username)) {
            throw new RuntimeException("Пользователь уже существует");
        }

        User user = new User();
        user.setUsername(username);
        user.setPassword(password); // Простое хранение пароля для демо
        user.setRole(role);

        return userRepository.save(user);
    }

    public boolean validatePassword(String rawPassword, String storedPassword) {
        return rawPassword.equals(storedPassword); // Простое сравнение для демо
    }
}
