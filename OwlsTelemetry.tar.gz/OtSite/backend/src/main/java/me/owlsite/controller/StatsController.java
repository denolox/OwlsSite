package me.owlsite.controller;

import me.owlsite.service.StatsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/stats")
@CrossOrigin(origins = "*")
public class StatsController {

    @Autowired
    private StatsService statsService;

    @GetMapping("/overview")
    public Map<String, Object> getOverview() {
        return statsService.getOverviewStats();
    }

    @GetMapping("/online")
    public Object getOnlinePlayers() {
        return statsService.getOnlinePlayers();
    }
}
