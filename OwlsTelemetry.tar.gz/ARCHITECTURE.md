# Архитектура OwlsTelemetry

## 📐 Общая структура

OwlsTelemetry построен по модульной архитектуре с четким разделением ответственности:

```
┌─────────────────────────────────────────────────────────┐
│                   OwlsTelemetry Plugin                  │
│                    (Main Class)                         │
└───────────────┬─────────────────────────────────────────┘
                │
    ┌───────────┼───────────┬──────────┬──────────────┐
    │           │           │          │              │
┌───▼────┐ ┌───▼────┐ ┌───▼────┐ ┌──▼──────┐ ┌─────▼──────┐
│Config  │ │Output  │ │Exploit │ │Data     │ │ Listeners  │
│Manager │ │Manager │ │Detector│ │Service  │ │  System    │
└────────┘ └───┬────┘ └────────┘ └─────────┘ └─────┬──────┘
               │                                     │
        ┌──────┴──────┐                    ┌────────┴────────┐
        │             │                    │                 │
   ┌────▼─────┐  ┌───▼────┐         ┌────▼─────┐     ┌────▼─────┐
   │  Event   │  │Discord │         │  Block   │     │  Player  │
   │  Logger  │  │Webhook │         │ Listener │     │ Listener │
   └──────────┘  └────────┘         └──────────┘     └──────────┘
```

## 🏗️ Модули системы

### 1. ConfigManager
**Назначение**: Управление конфигурацией плагина

**Ответственность**:
- Загрузка и валидация `config.yml`
- Предоставление типизированного доступа к настройкам
- Перезагрузка конфигурации без перезапуска

**Ключевые методы**:
```java
boolean isTrackingBlocks()
boolean isExploitDetectionEnabled()
String getDiscordWebhookUrl()
int getMaxBlocksPerSecond()
```

**Паттерны**: Singleton (один экземпляр на плагин)

---

### 2. OutputManager
**Назначение**: Координация вывода телеметрических данных

**Компоненты**:
- **EventLogger**: асинхронное логирование в JSON
- **DiscordWebhook**: отправка уведомлений в Discord

**Особенности**:
- Асинхронная обработка (не блокирует главный поток)
- Очередь событий для буферизации
- Автоматическая ротация файлов логов

**Потоковая модель**:
```
Main Thread → EventQueue → Logger Thread → File I/O
                        → Discord Thread → HTTP Request
```

---

### 3. ExploitDetector
**Назначение**: Детекция читов и аномального поведения

**Алгоритмы детекции**:

1. **Speed Mining** (частота действий)
   - Использует скользящее окно 1 секунда
   - Отслеживает количество блоков/действий
   - Порог настраивается в конфиге

2. **Reach** (дистанция взаимодействия)
   - Проверяет расстояние между игроком и блоком
   - Евклидова метрика
   - Учитывает лаг

3. **Fly** (подозрительное перемещение)
   - Анализ вертикального движения
   - Время нахождения в воздухе
   - Игнорирует легитимные полёты (creative, elytra)

4. **Speed** (аномальная скорость)
   - Расчет скорости на основе координат и времени
   - Учитывает эффекты зелий
   - Адаптивные пороги для транспорта

**Структуры данных**:
```java
ConcurrentHashMap<UUID, PlayerData>
  └─ Map<String, ActionTracker>
       └─ long[] timestamps (circular buffer)
```

---

### 4. DataService
**Назначение**: Доступ к собранным данным (API для фронтенда)

**Функциональность**:
- Чтение событий из логов
- Агрегация и статистика
- Экспорт в различные форматы

**Методы API**:
```java
List<JsonObject> getEvents(long start, long end)
List<JsonObject> getEventsByType(String type, int limit)
Map<String, Integer> getEventStatistics()
Map<String, Object> getPlayerStatistics(String uuid)
boolean exportToJson(long start, long end, File output)
```

**Оптимизация**:
- Ленивое чтение файлов (не загружает всё в память)
- Индексация по времени
- Поддержка больших объёмов данных

---

### 5. Listeners System
**Назначение**: Сбор событий от Bukkit/Paper API

#### BlockListener
- `BlockBreakEvent` → детекция speed mining → BlockEvent
- `BlockPlaceEvent` → детекция speed building → BlockEvent
- `PlayerInteractEvent` → проверка reach → BlockEvent

#### EntityListener
- `EntityDeathEvent` → EntityEvent (kill)
- `EntityTameEvent` → EntityEvent (tame)
- `EntityBreedEvent` → EntityEvent (breed)

#### ItemListener
- `EntityPickupItemEvent` → ItemEvent (pickup)
- `PlayerDropItemEvent` → ItemEvent (drop)
- `PlayerItemConsumeEvent` → ItemEvent (consume)

#### PlayerListener
- `PlayerJoinEvent` → PlayerConnectionEvent
- `PlayerQuitEvent` → PlayerConnectionEvent + session time
- `AsyncPlayerChatEvent` → ChatEvent
- `PlayerCommandPreprocessEvent` → CommandEvent
- `PlayerMoveEvent` → детекция fly/speed
- `PlayerAdvancementDoneEvent` → GameplayEvent

---

## 🔄 Поток данных

### 1. Сбор события
```
Minecraft Event → Bukkit Listener → Event Model (TelemetryEvent)
```

### 2. Обработка
```
TelemetryEvent → OutputManager → EventQueue
                              → ExploitDetector (если нужно)
```

### 3. Вывод
```
EventQueue → Logger Thread → JSON Serialization → File Write
          → Discord Thread → HTTP POST → Discord Webhook
```

### 4. Анализ (по запросу)
```
Command/API → DataService → File Read → JSON Parse → Aggregation
```

## 📦 Модель данных

### Базовая структура события
```json
{
  "event_type": "string",
  "timestamp": long,
  "data": {
    "player_uuid": "string",
    "player_name": "string",
    // ... специфичные поля
  }
}
```

### Иерархия классов
```
TelemetryEvent (abstract)
├── BlockEvent
├── EntityEvent
├── ItemEvent
├── PlayerConnectionEvent
├── ChatEvent
├── CommandEvent
├── GameplayEvent
└── ExploitAlertEvent

LocationData (helper)
```

## ⚡ Производительность

### Асинхронная обработка
- Все I/O операции выполняются асинхронно
- Использование `BukkitScheduler.runTaskAsynchronously()`
- Главный поток никогда не блокируется

### Потокобезопасность
- `ConcurrentHashMap` для shared state
- `BlockingQueue` для событий
- Атомарные операции где возможно

### Оптимизации
1. **Буферизация**: события накапливаются в очереди
2. **Batch запись**: группировка событий перед записью
3. **Lazy loading**: логи читаются по требованию
4. **Circular buffers**: для отслеживания частоты действий

### Метрики производительности
- Overhead на игрока: < 1%
- Latency добавления события: < 1ms
- Memory per player: ~10KB

## 🔐 Безопасность

### Ограничения
- Команды доступны только администраторам
- IP адреса можно скрыть в конфиге
- Чувствительные данные не логируются в Discord

### Валидация
- Проверка прав доступа перед каждой командой
- Валидация входных параметров
- Graceful degradation при ошибках

## 🔌 Расширяемость

### Точки расширения

1. **Новые типы событий**: наследовать `TelemetryEvent`
2. **Новые детекторы**: добавить методы в `ExploitDetector`
3. **Новые форматы вывода**: реализовать в `OutputManager`
4. **REST API**: использовать `DataService`

### Пример добавления нового события
```java
// 1. Создать модель
public class CustomEvent extends TelemetryEvent {
    public CustomEvent(...) {
        super("custom_event");
    }
    
    @Override
    protected JsonObject buildEventData() {
        // ...
    }
}

// 2. Создать listener
public class CustomListener implements Listener {
    @EventHandler
    public void onCustom(SomeEvent event) {
        CustomEvent ce = new CustomEvent(...);
        outputManager.handleEvent(ce);
    }
}

// 3. Зарегистрировать в OwlsTelemetry.java
pm.registerEvents(new CustomListener(...), this);
```

## 🧪 Тестирование

### Рекомендуемые unit-тесты
1. Event serialization/deserialization
2. ConfigManager загрузка значений
3. ExploitDetector пороговые значения
4. DataService агрегация данных

### Integration тесты
1. Полный цикл: событие → лог → чтение
2. Discord webhook отправка
3. Команды плагина

## 📊 Масштабирование

### Горизонтальное (несколько серверов)
- Централизованное хранилище (MySQL/PostgreSQL)
- Агрегация данных через внешний сервис
- Shared Redis для синхронизации

### Вертикальное (большой сервер)
- Отключение ненужных модулей tracking
- Увеличение max_file_size_mb
- Периодическая архивация старых логов

## 🔮 Будущие улучшения

1. **Database integration**: прямая запись в БД
2. **ProtocolLib support**: детальная телеметрия пакетов
3. **Machine Learning**: автоматическое обучение детекторов
4. **Web Dashboard**: визуализация в реальном времени
5. **Clustering**: поддержка BungeeCord/Velocity сетей

---

Эта архитектура обеспечивает:
- ✅ Модульность и расширяемость
- ✅ Высокую производительность
- ✅ Надежность и отказоустойчивость
- ✅ Простоту интеграции и использования

