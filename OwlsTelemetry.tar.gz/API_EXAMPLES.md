# OwlsTelemetry API Examples

Примеры использования DataService API для интеграции с внешними системами.

## 📚 Получение доступа к DataService

```java
// Из другого плагина
OwlsTelemetry plugin = (OwlsTelemetry) Bukkit.getPluginManager().getPlugin("OwlsTelemetry");
DataService dataService = plugin.getDataService();
```

## 🔍 Примеры использования

### 1. Получение событий за период времени

```java
// Получить все события за последние 24 часа
long endTime = System.currentTimeMillis();
long startTime = endTime - (24 * 3600000L); // 24 часа назад

List<JsonObject> events = dataService.getEvents(startTime, endTime);

for (JsonObject event : events) {
    String eventType = event.get("event_type").getAsString();
    long timestamp = event.get("timestamp").getAsLong();
    
    System.out.println("Event: " + eventType + " at " + new Date(timestamp));
}
```

### 2. Получение событий определенного типа

```java
// Получить последние 100 событий входа игроков
List<JsonObject> joinEvents = dataService.getEventsByType("player_join", 100);

for (JsonObject event : joinEvents) {
    JsonObject data = event.getAsJsonObject("data");
    String playerName = data.get("player_name").getAsString();
    String ipAddress = data.get("ip_address").getAsString();
    
    System.out.println(playerName + " connected from " + ipAddress);
}
```

### 3. Статистика игрока

```java
// Получить полную статистику игрока по UUID
Player player = Bukkit.getPlayer("Steve");
String uuid = player.getUniqueId().toString();

Map<String, Object> stats = dataService.getPlayerStatistics(uuid);

System.out.println("Player: " + stats.get("player_name"));
System.out.println("Total events: " + stats.get("total_events"));
System.out.println("Playtime: " + stats.get("total_playtime_minutes") + " minutes");

@SuppressWarnings("unchecked")
Map<String, Integer> eventCounts = (Map<String, Integer>) stats.get("event_counts");
System.out.println("Blocks broken: " + eventCounts.getOrDefault("block_break", 0));
```

### 4. Общая статистика сервера

```java
Map<String, Object> stats = dataService.getOverallStatistics();

System.out.println("Total events recorded: " + stats.get("total_events"));
System.out.println("Log files: " + stats.get("log_files_count"));
System.out.println("Total size: " + stats.get("total_size_mb") + " MB");

@SuppressWarnings("unchecked")
Map<String, Integer> eventTypes = (Map<String, Integer>) stats.get("event_types");
System.out.println("Most common event: " + getMostCommonEvent(eventTypes));
```

### 5. Экспорт данных

```java
// Экспортировать события за последнюю неделю
long endTime = System.currentTimeMillis();
long startTime = endTime - (7 * 24 * 3600000L); // 7 дней

File exportFile = new File("weekly_export.json");
boolean success = dataService.exportToJson(startTime, endTime, exportFile);

if (success) {
    System.out.println("Data exported to " + exportFile.getAbsolutePath());
}
```

### 6. Поиск событий эксплоитов

```java
// Получить все предупреждения об эксплоитах
List<JsonObject> exploits = dataService.getEventsByType("exploit_alert", 1000);

Map<String, Integer> cheaterStats = new HashMap<>();

for (JsonObject event : exploits) {
    JsonObject data = event.getAsJsonObject("data");
    String playerName = data.get("player_name").getAsString();
    String exploitType = data.get("exploit_type").getAsString();
    
    cheaterStats.put(playerName, cheaterStats.getOrDefault(playerName, 0) + 1);
    
    System.out.println(playerName + " suspected of: " + exploitType);
}

// Топ нарушителей
cheaterStats.entrySet().stream()
    .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
    .limit(10)
    .forEach(entry -> 
        System.out.println(entry.getKey() + ": " + entry.getValue() + " violations")
    );
```

### 7. Анализ активности игроков

```java
// Получить всех игроков, которые заходили за последние 7 дней
long weekAgo = System.currentTimeMillis() - (7 * 24 * 3600000L);
List<JsonObject> joinEvents = dataService.getEvents(weekAgo, System.currentTimeMillis());

Set<String> activeUsers = new HashSet<>();

for (JsonObject event : joinEvents) {
    if (event.get("event_type").getAsString().equals("player_join")) {
        JsonObject data = event.getAsJsonObject("data");
        String playerName = data.get("player_name").getAsString();
        activeUsers.add(playerName);
    }
}

System.out.println("Active users in the last week: " + activeUsers.size());
```

### 8. Создание отчета о действиях игрока

```java
public void generatePlayerReport(Player player) {
    String uuid = player.getUniqueId().toString();
    List<JsonObject> playerEvents = dataService.getPlayerEvents(uuid, Integer.MAX_VALUE);
    
    int blocksPlaced = 0;
    int blocksBroken = 0;
    int mobsKilled = 0;
    int deaths = 0;
    
    for (JsonObject event : playerEvents) {
        String type = event.get("event_type").getAsString();
        
        switch (type) {
            case "block_place": blocksPlaced++; break;
            case "block_break": blocksBroken++; break;
            case "entity_kill": mobsKilled++; break;
            case "player_death": deaths++; break;
        }
    }
    
    System.out.println("=== Player Report: " + player.getName() + " ===");
    System.out.println("Blocks placed: " + blocksPlaced);
    System.out.println("Blocks broken: " + blocksBroken);
    System.out.println("Mobs killed: " + mobsKilled);
    System.out.println("Deaths: " + deaths);
    System.out.println("K/D Ratio: " + (deaths > 0 ? (double)mobsKilled/deaths : mobsKilled));
}
```

## 🌐 REST API (Пример будущей реализации)

### Концепция простого HTTP сервера

```java
public class TelemetryWebServer {
    private final DataService dataService;
    private HttpServer server;
    
    public void start(int port) throws IOException {
        server = HttpServer.create(new InetSocketAddress(port), 0);
        
        // GET /api/events?start=...&end=...
        server.createContext("/api/events", exchange -> {
            long start = Long.parseLong(getQueryParam(exchange, "start"));
            long end = Long.parseLong(getQueryParam(exchange, "end"));
            
            List<JsonObject> events = dataService.getEvents(start, end);
            String json = new Gson().toJson(events);
            
            sendJsonResponse(exchange, json);
        });
        
        // GET /api/player/{uuid}
        server.createContext("/api/player/", exchange -> {
            String path = exchange.getRequestURI().getPath();
            String uuid = path.substring(path.lastIndexOf('/') + 1);
            
            Map<String, Object> stats = dataService.getPlayerStatistics(uuid);
            String json = new Gson().toJson(stats);
            
            sendJsonResponse(exchange, json);
        });
        
        // GET /api/stats
        server.createContext("/api/stats", exchange -> {
            Map<String, Object> stats = dataService.getOverallStatistics();
            String json = new Gson().toJson(stats);
            
            sendJsonResponse(exchange, json);
        });
        
        server.setExecutor(null);
        server.start();
        
        System.out.println("Web API started on port " + port);
    }
    
    private void sendJsonResponse(HttpExchange exchange, String json) throws IOException {
        byte[] response = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.sendResponseHeaders(200, response.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(response);
        }
    }
}
```

### Использование с фронтендом (JavaScript)

```javascript
// Получить статистику сервера
fetch('http://localhost:8080/api/stats')
    .then(response => response.json())
    .then(data => {
        console.log('Total events:', data.total_events);
        console.log('Event types:', data.event_types);
    });

// Получить события игрока
const playerUUID = 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx';
fetch(`http://localhost:8080/api/player/${playerUUID}`)
    .then(response => response.json())
    .then(data => {
        console.log('Player name:', data.player_name);
        console.log('Total events:', data.total_events);
        console.log('Playtime:', data.total_playtime_minutes, 'minutes');
    });

// Получить события за период
const now = Date.now();
const yesterday = now - (24 * 60 * 60 * 1000);
fetch(`http://localhost:8080/api/events?start=${yesterday}&end=${now}`)
    .then(response => response.json())
    .then(events => {
        console.log('Events in last 24h:', events.length);
        
        // Группировка по типам
        const eventTypes = {};
        events.forEach(event => {
            const type = event.event_type;
            eventTypes[type] = (eventTypes[type] || 0) + 1;
        });
        
        console.log('Event distribution:', eventTypes);
    });
```

## 📊 Интеграция с базами данных (Концепция)

### Миграция данных в MySQL

```java
public class DatabaseMigration {
    private final DataService dataService;
    private final Connection connection;
    
    public void migrateToDatabase() throws SQLException {
        // Создание таблиц
        createTables();
        
        // Получение всех событий
        long now = System.currentTimeMillis();
        long monthAgo = now - (30L * 24 * 3600000);
        List<JsonObject> events = dataService.getEvents(monthAgo, now);
        
        // Вставка в БД
        String sql = "INSERT INTO telemetry_events (event_type, timestamp, data) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            for (JsonObject event : events) {
                stmt.setString(1, event.get("event_type").getAsString());
                stmt.setLong(2, event.get("timestamp").getAsLong());
                stmt.setString(3, event.toString());
                stmt.addBatch();
            }
            stmt.executeBatch();
        }
        
        System.out.println("Migrated " + events.size() + " events to database");
    }
    
    private void createTables() throws SQLException {
        String sql = """
            CREATE TABLE IF NOT EXISTS telemetry_events (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                event_type VARCHAR(100),
                timestamp BIGINT,
                data JSON,
                INDEX idx_type (event_type),
                INDEX idx_timestamp (timestamp)
            )
        """;
        
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(sql);
        }
    }
}
```

## 🔌 Расширение функциональности

### Создание собственного обработчика событий

```java
public class CustomTelemetryHandler {
    private final OutputManager outputManager;
    
    public void onCustomEvent(Player player, String action) {
        // Создание кастомного события
        JsonObject customEvent = new JsonObject();
        customEvent.addProperty("event_type", "custom_action");
        customEvent.addProperty("timestamp", System.currentTimeMillis());
        
        JsonObject data = new JsonObject();
        data.addProperty("player_uuid", player.getUniqueId().toString());
        data.addProperty("player_name", player.getName());
        data.addProperty("action", action);
        customEvent.add("data", data);
        
        // Можно создать свой класс события, наследующий TelemetryEvent
        // и использовать outputManager.handleEvent()
    }
}
```

## 📝 Заключение

DataService предоставляет мощный API для работы с собранными данными. Вы можете:

1. **Читать события** - по времени, типу, игроку
2. **Агрегировать данные** - статистика, отчеты, аналитика  
3. **Экспортировать** - в JSON, базы данных, внешние системы
4. **Интегрировать** - с веб-интерфейсами, ботами, другими плагинами

Это делает OwlsTelemetry идеальным фундаментом для создания системы мониторинга и аналитики вашего сервера.

---

Для получения дополнительной помощи обратитесь к основной документации в [README.md](README.md).

